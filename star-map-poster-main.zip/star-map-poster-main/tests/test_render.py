from src.astronomy import get_sky_data
from src.fullsky import FullSkyMap
import os

# get sky data
stars, planets  = get_sky_data(
    city     = "Chandigarh",
    date_str = "1998-02-19",
    time_str = "14:57"
)

# create and render map
skymap = FullSkyMap(
    stars    = stars,
    planets  = planets,
    title    = "The Stars When The Brightest Star Was Born",
    location = "Chandigarh",
    date_str = "19th February 1998",
    time_str = "2:57 PM"
)

skymap.render()

# save outputs
os.makedirs("outputs", exist_ok=True)
skymap.save("outputs/starmap.png", "outputs/starmap.pdf")