from src.astronomy import get_sky_data

# Test with Priya's birthday — same as the sample poster
stars, planets = get_sky_data(
    city      = "Chandigarh",
    date_str  = "1998-02-19",
    time_str  = "14:57"
)

print(f"\n✅ Done — {len(stars)} stars, {len(planets)} planets computed")
print("\nSample stars:")
print(stars[['magnitude', 'alt', 'az']].head(10))