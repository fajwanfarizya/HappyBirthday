import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from src.starmap import StarMap


class FullSkyMap(StarMap):
    """
    Full sky map showing:
    - Inner dark circle  : stars above horizon (Alt > 0°)
    - Outer faded ring   : stars in twilight zone (Alt -18° to 0°)
    """

    def __init__(self, stars, planets, title="Star Map",
                 location="", date_str="", time_str=""):
        super().__init__(stars, planets, title)
        self.location = location
        self.date_str = date_str
        self.time_str = time_str


    # ── RENDER ────────────────────────────────────────────────────

    def render(self):
        self.fig = plt.figure(figsize=(10, 10), facecolor='#0B1426')
        self.ax  = self.fig.add_subplot(111, aspect='equal')
        self.ax.set_facecolor('#0B1426')
        self.ax.set_xlim(-1.6, 1.6)
        self.ax.set_ylim(-1.6, 1.6)
        self.ax.axis('off')

        # ── Layer 1: Outer twilight ring ──
        outer = plt.Circle((0, 0), 1.44, color='#1B2D4F', zorder=0)
        self.ax.add_patch(outer)

        # ── Layer 2: Inner sky circle ──
        inner = plt.Circle((0, 0), 1.0, color='#0D1B36', zorder=1)
        self.ax.add_patch(inner)

        # ── ADD CLIPPING to inner circle ──
        from matplotlib.patches import Circle
        clip_circle = Circle((0, 0), 1.0, transform=self.ax.transData)

        # ── Layer 3: Constellation lines (clipped) ──
        self._draw_constellations(self.ax, self.stars, alpha=0.35)

        # ── Layer 4: Twilight stars ──
        self._draw_stars(self.ax, alt_min=-18, alpha=0.15, color='#8AAFD4')

        # ── Layer 5: Visible stars ──
        self._draw_stars(self.ax, alt_min=0, alpha=0.9, color='white')

        # ── Layer 5A: Named stars ──
        self._draw_named_stars(self.ax, self.stars)

        # ── Layer 6: Planets ──
        self._draw_planets(self.ax, alt_min=-18)



        # ── Layer 7: Horizon circle ──
        self._draw_horizon_circle(self.ax, radius=1.0,
                                color='#4A6FA5', linewidth=1.5)

        # ── Layer 8: Outer boundary ──
        self._draw_horizon_circle(self.ax, radius=1.44,
                                color='#2A4A7F', linewidth=1.0)

        # ── Layer 9: Compass ──
        self._draw_compass(self.ax, radius=1.0)

        # ── Layer 10: Horizon labels ──
        self._draw_horizon_labels()

        # ── Layer 11: Title ──
        self._draw_title()

        plt.tight_layout()
        return self


    # ── HORIZON LABELS ────────────────────────────────────────────

    def _draw_horizon_labels(self):
        """Draw Northern/Southern/Eastern/Western horizon text"""
        labels = [
            ('Northern horizon', 0.0,   0.88),
            ('Southern horizon', 0.0,  -0.88),
            ('Eastern horizon', -0.88,  0.0,  90),
            ('Western horizon',  0.88,  0.0,  90),
        ]
        for item in labels:
            text  = item[0]
            x, y  = item[1], item[2]
            angle = item[3] if len(item) > 3 else 0

            self.ax.text(x, y, text,
                        color='white',
                        fontsize=7,
                        alpha=0.7,
                        ha='center',
                        va='center',
                        rotation=angle,
                        zorder=9)


    # ── TITLE ─────────────────────────────────────────────────────

    def _draw_title(self):
        """Draw title, location, date at bottom of figure"""
        self.fig.text(0.5, 0.02,
                     f"{self.location}  •  {self.date_str}  •  {self.time_str}",
                     color='#8AAFD4',
                     fontsize=9,
                     ha='center')

        self.fig.text(0.5, 0.96,
                     self.title,
                     color='#C8A96E',
                     fontsize=16,
                     fontweight='bold',
                     ha='center')