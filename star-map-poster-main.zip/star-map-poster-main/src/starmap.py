import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from abc import ABC, abstractmethod
from src.constellation_data import CONSTELLATIONS


class StarMap(ABC):
    """
    Abstract base class for all star map styles.
    Contains shared data + shared drawing methods.
    Subclasses must implement render().
    """

    # ── Planet colors ─────────────────────────────────────────────
    PLANET_COLORS = {
        'Sun'    : '#FFF176',
        'Moon'   : '#B0BEC5',
        'Mercury': '#90A4AE',
        'Venus'  : '#FFCC80',
        'Mars'   : '#EF9A9A',
        'Jupiter': '#FFCC80',
        'Saturn' : '#CE93D8',
    }

    def __init__(self, stars, planets, 
     title="Star Map"):
        """
        stars   : pandas DataFrame with columns alt, az, magnitude
        planets : list of dicts with keys name, alt, az
        constellation_lines : list of (name, [(hip_id, hip_id), ...])
        title   : string shown on poster
        """
        self.stars   = stars
        self.planets = planets
        self.title   = title
        self.fig     = None
        self.ax      = None


    # ── 1. PROJECTION ─────────────────────────────────────────────

    def _project(self, alt, az): 
        """
        Convert Alt/Az → X/Y on unit circle.

        Alt  90° = center (zenith)
        Alt   0° = edge of inner circle (horizon)
        Alt -18° = outer edge of twilight ring

        Az    0° = North = top
        Az   90° = East  = left (sky is mirrored vs map)
        Az  180° = South = bottom
        Az  270° = West  = right
        """
        alt = np.asarray(alt)
        az  = np.asarray(az)

        # distance from center
        # Alt 90° → r=0, Alt 0° → r=1, Alt -18° → r=1.44
        r = 1 - (alt / 90.0)

        # convert az to radians
        theta = np.radians(az)

        # x/y — note East is LEFT in sky maps
        x = -r * np.sin(theta)
        y = r * np.cos(theta)

        return x, y


    # ── 2. STAR SIZE ──────────────────────────────────────────────

    def _star_size(self, magnitude):
        """
        Convert star magnitude to dot size for scatter plot.
        Magnitude scale is INVERTED — lower = brighter.
        Magnitude 1 = very bright, Magnitude 6 = barely visible.
        """
        return np.clip((6.5 - magnitude) ** 1.8, 0.5, 40)


    # ── 3. DRAW STARS ─────────────────────────────────────────────

    def _draw_stars(self, ax, alt_min=0, alpha=1.0, color='white'):
        """
        Draw stars as scatter plot dots.

        alt_min : only draw stars with alt >= alt_min
        alpha   : transparency (1.0 = full, 0.3 = faded for twilight)
        color   : dot color
        """
        subset = self.stars[self.stars['alt'] >= alt_min]

        if alt_min < 0:
            # twilight zone only — between -18 and 0
            subset = self.stars[
                (self.stars['alt'] >= alt_min) &
                (self.stars['alt'] <  0)
            ]

        x, y = self._project(subset['alt'].values, subset['az'].values)
        sizes = self._star_size(subset['magnitude'].values)

        ax.scatter(x, y,
                   s=sizes,
                   c=color,
                   alpha=alpha,
                   linewidths=0,
                   zorder=3)
    # ── 3A. DRAW NAMED STARS ─────────────────────────────────────────────
    def _draw_named_stars(self, ax, stars_df):
        """Draw green labels for named bright stars"""
        from src.star_names import NAMED_STARS

        for hip_id, name in NAMED_STARS.items():
            if hip_id not in stars_df.index:
                continue

            star = stars_df.loc[hip_id]

            # show in inner circle at full brightness
            # show in outer ring faded
            if star['alt'] < -18:
                continue

            x, y  = self._project(star['alt'], star['az'])
            alpha = 1.0 if star['alt'] >= 0 else 0.4
            color = '#90EE90' if star['alt'] >= 0 else '#4a7a4a'

            # draw a slightly larger dot for named stars
            size = max(self._star_size(star['magnitude']) * 1.5, 15)
            ax.scatter(x, y, s=size, c='white',
                    alpha=alpha, linewidths=0, zorder=7)

            # label offset — avoid overlapping the dot
            ax.annotate(name, (x, y),
                    xytext=(5, 5),
                    textcoords='offset points',
                    color=color,
                    fontsize=6,
                    alpha=alpha,
                    zorder=8,
                    fontfamily='serif')
    # ── 3B. DRAW CONSTELLATIONS ─────────────────────────────────────────────
    def _draw_constellations(self, ax, stars_df, alpha=0.4):
        for abbrev, (full_name, pairs) in CONSTELLATIONS.items():
            label_x, label_y, pair_count = 0, 0, 0

            for hip_start, hip_end in pairs:
                if hip_start not in stars_df.index or \
                hip_end   not in stars_df.index:
                    continue

                star_a = stars_df.loc[hip_start]
                star_b = stars_df.loc[hip_end]

                if star_a['alt'] < -18 or star_b['alt'] < -18:
                    continue

                # full brightness if both above horizon, faded if either in twilight zone
                both_above = star_a['alt'] >= 0 and star_b['alt'] >= 0
                #line_alpha = alpha if both_above else alpha * 0.3

                x_a, y_a = self._project(star_a['alt'], star_a['az'])
                x_b, y_b = self._project(star_b['alt'], star_b['az'])

                r_a = np.sqrt(x_a**2 + y_a**2)
                r_b = np.sqrt(x_b**2 + y_b**2)

                if r_a > 1.44 or r_b > 1.44:
                    continue

                ax.plot([x_a, x_b], [y_a, y_b],
                    color='#E8A882',
                    linewidth=0.5,
                    alpha=alpha,
                    zorder=2)

                label_x += (x_a + x_b) / 2
                label_y += (y_a + y_b) / 2
                pair_count += 1

            if pair_count > 0:
                cx = label_x / pair_count
                cy = label_y / pair_count
                if np.sqrt(cx**2 + cy**2) < 0.92:
                    ax.text(cx, cy, full_name,
                        color='white',
                        fontsize=5.5,
                        alpha=0.7,
                        ha='center',
                        va='center',
                        zorder=6,
                        fontfamily='serif')

    # ── 4. DRAW PLANETS ───────────────────────────────────────────

    def _draw_planets(self, ax, alt_min=-18):
        """Draw planets as glowing colored dots with labels"""
        for planet in self.planets:
            alt = planet['alt']
            az  = planet['az']

            if alt < alt_min:
                continue  # too far below horizon, skip

            x, y = self._project(alt, az)

            color = self.PLANET_COLORS.get(planet['name'], 'white')
            alpha = 1.0 if alt >= 0 else 0.4  # faded if below horizon

            # outer glow
            ax.scatter(x, y, s=200, c=color, alpha=alpha * 0.3,
                      linewidths=0, zorder=4)
            # inner dot
            ax.scatter(x, y, s=60, c=color, alpha=alpha,
                      linewidths=0, zorder=5)
            # label
            ax.annotate(planet['name'],
                       (x, y),
                       xytext=(6, 6),
                       textcoords='offset points',
                       color=color,
                       fontsize=7,
                       alpha=alpha,
                       zorder=6)


    # ── 5. DRAW COMPASS ───────────────────────────────────────────

    def _draw_compass(self, ax, radius=1.0):
        """Draw N/S/E/W labels around the horizon circle"""
        labels = {
            'N': ( 0.0,        radius + 0.08),
            'S': ( 0.0,       -radius - 0.08),
            'E': (-radius - 0.08,  0.0),       # East is LEFT
            'W': ( radius + 0.08,  0.0),
        }
        for label, (x, y) in labels.items():
            ax.text(x, y, label,
                   color='white',
                   fontsize=11,
                   fontweight='bold',
                   ha='center',
                   va='center',
                   zorder=7)


    # ── 6. DRAW HORIZON CIRCLE ────────────────────────────────────

    def _draw_horizon_circle(self, ax, radius=1.0, color='#4A6FA5',
                              linewidth=1.5):
        """Draw the horizon boundary circle"""
        circle = plt.Circle((0, 0), radius,
                            fill=False,
                            color=color,
                            linewidth=linewidth,
                            zorder=8)
        ax.add_patch(circle)


    # ── 7. ABSTRACT METHOD ────────────────────────────────────────

    @abstractmethod
    def render(self):
        """
        Subclasses must implement this.
        Should set self.fig and self.ax and draw everything.
        """
        pass


    # ── 8. SAVE ───────────────────────────────────────────────────

    def save(self, path_png, path_pdf):
        """Save the rendered map as PNG and PDF"""
        if self.fig is None:
            raise RuntimeError("Call render() before save()")

        self.fig.savefig(path_png,
                        dpi=300,
                        bbox_inches='tight',
                        facecolor=self.fig.get_facecolor())

        self.fig.savefig(path_pdf,
                        bbox_inches='tight',
                        facecolor=self.fig.get_facecolor())

        print(f"💾 Saved → {path_png}")
        print(f"💾 Saved → {path_pdf}")