"""
Named bright stars — Hipparcos ID → common name
These are labeled in green on the star map
"""

NAMED_STARS = {
    11767 : 'Polaris',
    27989 : 'Betelgeuse',
    24436 : 'Rigel',
    21421 : 'Aldebaran',
    32349 : 'Sirius',
    37279 : 'Procyon',
    36850 : 'Castor',
    37826 : 'Pollux',
    49669 : 'Regulus',
    65474 : 'Spica',
    69673 : 'Arcturus',
    91262 : 'Vega',
    102098: 'Deneb',
    97649 : 'Altair',
    80763 : 'Antares',
    113368: 'Fomalhaut',
    30438 : 'Canopus',
    33347 : 'Adara',
    25336 : 'Bellatrix',
    26727 : 'Mintaka',
    27366 : 'Alnilam',
    28691 : 'Alnitak',
    25428 : 'Capella',
    57632 : 'Denebola',
    72105 : 'Arcturus',
    68702 : 'Hadar',
    71683 : 'Rigil Kent',
    9884  : 'Hamal',
    677   : 'Alpheratz',
    15863 : 'Mirfak',
    7588  : 'Achernar',
}