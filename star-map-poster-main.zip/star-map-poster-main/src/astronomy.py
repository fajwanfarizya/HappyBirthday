from skyfield.api import load, Star, wgs84
from skyfield.data import hipparcos, stellarium, mpc
from geopy.geocoders import Nominatim
from datetime import datetime
import pytz
from timezonefinder import TimezoneFinder
import os
import warnings

warnings.filterwarnings('ignore')

# ── 1. GEOCODING ──────────────────────────────────────────────────────────────

def get_coordinates(city_name):
    """Convert city name to (latitude, longitude)"""
    geolocator = Nominatim(user_agent="star-map-poster")
    location = geolocator.geocode(city_name)

    if location is None:
        raise ValueError(f"City not found: {city_name}")

    print(f"📍 {city_name} → lat={location.latitude}, lon={location.longitude}")
    return location.latitude, location.longitude


# ── 2. LOAD SKYFIELD DATA ─────────────────────────────────────────────────────

def load_skyfield_data():
    from skyfield.api import Loader

    load_data = Loader('data/cache')
    ts  = load_data.timescale()
    eph = load_data('de440s.bsp')

    with load_data.open(hipparcos.URL) as f:
        stars = hipparcos.load_dataframe(f)

    # ── NEW: load constellation lines ──
    # load constellation lines via direct URL
    constellation_lines = [] 

    stars = stars[stars['magnitude'] < 6.0]
    print(f"⭐ Loaded {len(stars)} visible stars")
    print(f"🔭 Loaded {len(constellation_lines)} constellations")

    return ts, eph, stars, constellation_lines


# ── 3. COMPUTE STAR POSITIONS ─────────────────────────────────────────────────

def compute_star_positions(ts, eph, stars, lat, lon, dt):
    """
    Convert star RA/Dec → Alt/Az for a specific observer + time
    dt: Python datetime object (local time)
    """
    # Create observer location on Earth
    observer = wgs84.latlon(lat, lon)

    # Convert datetime to Skyfield time object
    t = ts.from_datetime(dt)

    # Earth + observer position
    obs = eph['earth'] + observer

    # compute Alt/Az without gravitational deflection
    star_obj = Star.from_dataframe(stars)
    astrometric = obs.at(t).observe(star_obj)

    # manually compute alt/az from astrometric without calling .apparent()
    from skyfield.positionlib import Apparent
    apparent = astrometric
    apparent.__class__ = Apparent
    
    alt, az, distance = apparent.altaz()

    stars = stars.copy()
    stars['alt'] = alt.degrees
    stars['az'] = az.degrees

    # # Only keep stars above horizon
    # visible = stars[stars['alt'] > 0].copy()

    # ── NOW (all three zones) ──
    visible   = stars[stars['alt'] > 0].copy()
    twilight  = stars[(stars['alt'] >= -18) & (stars['alt'] <= 0)].copy()
    all_stars = stars[stars['alt'] >= -18].copy()

    print(f"🌟 {len(visible)} stars above horizon")
    print(f"🌆 {len(twilight)} stars in twilight zone")
    return all_stars 


# ── 4. COMPUTE PLANET POSITIONS ───────────────────────────────────────────────

def compute_planet_positions(ts, eph, lat, lon, dt):
    """Get Alt/Az for solar system bodies"""
    observer = wgs84.latlon(lat, lon)
    t = ts.from_datetime(dt)
    earth = eph['earth']
    obs = earth + observer

    bodies = {
        'Sun'    : eph['sun'],
        'Moon'   : eph['moon'],
        'Mercury': eph['mercury'],
        'Venus'  : eph['venus'],
        'Mars'   : eph['mars barycenter'],
        'Jupiter': eph['jupiter barycenter'],
        'Saturn' : eph['saturn barycenter'],
    }

    planets = []
    for name, body in bodies.items():
        astrometric = obs.at(t).observe(body)
        alt, az, _ = astrometric.apparent().altaz()
        planets.append({
            'name': name,
            'alt' : alt.degrees,
            'az'  : az.degrees,
        })
        print(f"🪐 {name:8s} → alt={alt.degrees:.1f}°, az={az.degrees:.1f}°")

    return planets


# ── 5. MAIN FUNCTION ──────────────────────────────────────────────────────────

def get_sky_data(city, date_str, time_str):
    """
    Master function — given city + date + time,
    returns visible stars and planet positions

    date_str: "1998-02-19"
    time_str: "14:57"
    """
    # Parse date and time
    dt_str = f"{date_str} {time_str}"
    dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M")

    print(f"\n🔭 Computing sky for {city} on {dt}\n")

    lat, lon = get_coordinates(city)

    # ── NEW: auto-detect timezone from coordinates ──
    tf = TimezoneFinder()
    tz_name = tf.timezone_at(lat=lat, lng=lon)
    tz = pytz.timezone(tz_name)
    dt = tz.localize(dt)
    print(f"🕐 Timezone: {tz_name} ({dt})")
    # ────────────────────────────────────────────────

    ts, eph, stars, constellation_lines = load_skyfield_data()
    all_stars = compute_star_positions(ts, eph, stars, lat, lon, dt)
    planets = compute_planet_positions(ts, eph, lat, lon, dt)

    return all_stars, planets  